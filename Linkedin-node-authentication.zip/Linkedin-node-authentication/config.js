module.exports = {
    'linkedinAuth': {
      'clientID': '78iv94rxk4f7lr', // your App ID
      'clientSecret': 'Nlm8SqJ2njlDzTVA', // your App Secret
      'callbackURL': 'http://127.0.0.1:3000/auth/linkedin/callback'
      
      
    }
  }